"""CANDOR system assembly — the §5 agent-facing API over core + periphery.

This is the only module that knows about both halves of the tree. It holds no
epistemic logic of its own: it sequences ledger appends, hands candidates to the
gate, and composes read-time views. Everything it writes goes through
`core.apply.apply_event`, so the live index is replay-equivalent by
construction (I1, I3).
"""

from __future__ import annotations

import json
import math
import shutil
import tempfile
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Optional, Sequence

from .core import apply as apply_mod
from .core import calibration as calibration_mod
from .core import closure as closure_mod
from .core import constraints as constraints_mod
from .core import gate as gate_mod
from .core import kernel as kernel_mod
from .core.canonical import context_signature, fact_key
from .core.committed import counts as counts_mod
from .core.committed import facts as facts_mod
from .core.committed import reliability as reliability_mod
from .core.hashing import GENESIS, canon_json
from .core.index import Index
from .core.ledger import Ledger, is_payload_hash
from .periphery import conjecture as conjecture_mod
from .periphery import curiosity as curiosity_stats_mod
from .periphery import curiosity_engine as curiosity_mod
from .periphery import embedder as embedder_mod
from .periphery import extractor as extractor_mod
from .periphery import predict as predict_mod
from .periphery.retrieval import RetrievalLog, Retriever

REFUSED = "Refused"

# In-memory operational log surfaced by health(). It is NOT replay state (it
# never touches the ledger), so a long-lived process must not let it grow
# without bound (M11b); the newest entries are the ones worth keeping.
_HEALTH_EVENTS_CAP = 1000


class QuotaExceeded(RuntimeError):
    """§3.12 flooding bound. Raised at the API boundary, before the ledger."""


class Unauthorized(RuntimeError):
    """A registered authorization policy denied a privileged write (M3).

    Raised at the API boundary, before any ledger append, so a denied call
    mutates nothing. Only ever raised when `set_authz` has installed a policy;
    the default posture is advisory (see SECURITY.md)."""


class Refused(RuntimeError):
    """§3.8: an unsettleable claim is refused entry and stays prose."""


@dataclass(frozen=True)
class DeriveOutcome:
    status: str                       # 'proof' | 'not_entailed' | 'budget_exceeded'
    proof: Optional[dict[str, Any]]
    search_exhausted: bool
    quality: str = "proof"


@dataclass(frozen=True)
class PredictOutcome:
    p: float
    ci: tuple[float, float]
    channels: dict[str, float]
    sensitivity: dict[str, float]
    mpe: Any
    caveats: frozenset[str]
    snapshot_id: str
    rejection_rate: float


@dataclass(frozen=True)
class CategoricalPrediction:
    """predict()'s return for a categorical fact (design §2.4): a DISTRIBUTION
    over an open vocabulary plus a first-class unknown mass — not a scalar p.

    `values` maps each seen value to its {p, ci} slice in canonical order
    (ORDER BY value); `unknown` is the never-seen mass with its own interval.
    `Σ values[*].p + unknown.p == 1.0` exactly by construction (§2.1).

    `by_context` (C4, design §3) is the value distribution CONDITIONED on a
    discovered conditioning key: ``{key: {context_value: {"values": {...},
    "unknown": slice, "n": int}}}``. Each context group carries its OWN CRP
    predictive with its own unknown slice, plus a ``__residual__`` group for
    observations that did not record the key — the honest "cannot attribute" mass
    kept distinct from the per-context unknown slices. Empty unless the curiosity
    sweep admitted a guard conditioning this fact on a key (§7)."""
    values: dict[str, counts_mod.CategoricalSlice]
    unknown: counts_mod.CategoricalSlice
    total_observations: int
    snapshot_id: str
    caveats: frozenset[str]
    by_context: dict[str, dict[str, dict[str, Any]]] = field(default_factory=dict)


class CandorSystem:
    """One store. Single writer to the gate, single sequencer for the ledger."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.ledger = Ledger(self.root / "ledger")
        self.index = Index(self.root / "index.sqlite3")
        self.retrieval_log = RetrievalLog(self.root / "retrieval.sqlite3")
        self.retriever = Retriever(
            evidence_dir=self.root / "evidence",
            payload_dir=self.root / "ledger" / "payloads",
            log=self.retrieval_log,
            dense=embedder_mod.from_env(self.root))   # v0.3 Δ5: optional, injected
        self._closure: Optional[closure_mod.Closure] = None
        self._calib = calibration_mod.IsotonicMap()
        self._health_events: deque[dict[str, Any]] = deque(maxlen=_HEALTH_EVENTS_CAP)
        # M11c: max observation event_seq the last run_gate sweep processed. The
        # sweep is a pure function of the observed facts, so with this unchanged
        # it would re-propose byte-identical candidates — an idle run_gate can
        # skip it. None until the first sweep actually runs.
        self._sweep_obs_watermark: Optional[int] = None
        # Δ11: same idea for the prospective guard audit — its verdicts depend
        # only on observations, so with no new observation nothing can change.
        self._audit_obs_watermark: Optional[int] = None
        # M3: optional authorization policy for privileged writes. None means
        # advisory (the default posture): `authority`/`actor` are attribution
        # labels only. A policy is a callable (principal, op) -> bool; see
        # set_authz. It is a runtime guard like the quota limits — not ledger
        # state — so it never enters the closure hash and replay never re-checks
        # it (every event already in the chain was admitted when written).
        self._authz: Optional[Callable[[str, str], bool]] = None
        self.open()

    # ── lifecycle ────────────────────────────────────────────────────────────
    def open(self) -> None:
        (self.root / "evidence").mkdir(parents=True, exist_ok=True)
        self.ledger.open()
        self.index.open()
        self._refold()

    def reset(self) -> None:
        self.ledger.destroy()
        self.index.reset()
        self._clear_checkpoints()
        self._closure = None
        self._health_events = deque(maxlen=_HEALTH_EVENTS_CAP)
        self._sweep_obs_watermark = None
        self._audit_obs_watermark = None
        self.ledger.open()

    def close(self) -> None:
        self.ledger.close()
        self.index.close()
        self.retrieval_log.close()

    # ── replay (§6.1 hook, I1) ───────────────────────────────────────────────
    def _refold(self, use_checkpoint: bool = True) -> None:
        """Fold the log into a fresh index. Redaction implies exclusion.

        Fast path (a DROPPABLE optimization, never a primary artifact — I1): when
        a VALID checkpoint exists, restore the derived index to the pre-sweep
        folded snapshot it froze and fold only the tail after it, instead of
        re-folding from genesis. The snapshot is taken BEFORE the curiosity sweep
        (which sets some flags monotonically), so restore + tail-fold + one sweep
        over the complete observation set is byte-identical to a full replay. A
        checkpoint at seq S is only used if no retraction/redaction exists at
        seq > S (those retroactively rewrite events at seq <= S that the snapshot
        already froze) and if its file passes an integrity probe; otherwise we
        fall back to a full fold. See `_select_checkpoint`.
        """
        # Start from an empty index unconditionally (C1): the count writers are
        # increments, so folding onto a non-empty index re-adds every prior
        # count. open() used to skip this and double-count on every reopen;
        # replay/retract_source/redact already reset and now just reset twice
        # (harmless), matching this method's "fresh index" contract.
        self.index.reset()
        redacted = self._redacted_payloads()
        retracted = self._retracted_actors()
        start_seq = 0
        if use_checkpoint:
            cp = self._select_checkpoint()
            if cp is not None and self.index.restore_from(cp[2]):
                start_seq = cp[0]
        self._last_checkpoint_seq = start_seq
        folded = 0
        for ev in self.ledger.read_all():
            if ev.seq <= start_seq:
                continue           # already frozen in the restored checkpoint
            # A retracted source keeps its event skeletons forever (nothing is
            # erased) but contributes no payload, so every downstream number
            # recomputes as if it never spoke. Retraction events themselves are
            # always applied, or retracting an operator would be irreversible.
            silenced = ev.actor in retracted and ev.kind != "retraction"
            payload = (None if silenced or ev.payload_hash in redacted
                       else self.ledger.payload(ev.payload_hash))
            apply_mod.apply_event(self.index, ev, payload)
            folded += 1
        self._last_tail_folded = folded
        # Reliability overrides fold in naturally now (they are `reliability`
        # events), in true ledger order — no post-fold re-application (I3).
        # Replay determinism: flags/questions/breadth are a deterministic
        # function of the folded observations, so re-derive them here.
        #
        # H6b: the restored snapshot is POST-sweep, so only facts with a NEW
        # observation in the tail can have a changed verdict. On the fast path
        # re-sweep just those (each from its full observation set — provably ==
        # a full sweep for them); untouched facts keep their snapshot verdict.
        # On a full-from-genesis fold (start_seq==0, incl. every retraction/
        # redaction/restore fallback) the index is blank, so we FULL-sweep.
        if start_seq > 0:
            touched = [r["fact_id"] for r in self.index.query(
                "SELECT DISTINCT fact_id FROM observations "
                "WHERE event_seq > ? AND fact_id IS NOT NULL ORDER BY fact_id",
                (start_seq,))]
            curiosity_mod.resweep(self.index, touched)
            self._last_resweep_ids = touched
        else:
            curiosity_mod.sweep(self.index)
            self._last_resweep_ids = None
        self.index.commit()
        self._closure = None

    # ── checkpoints (droppable derived-state cache, spec §6.4 / SPEC:336) ────
    def _checkpoint_dir(self) -> Path:
        return self.root / "checkpoints"

    def _clear_checkpoints(self) -> None:
        d = self._checkpoint_dir()
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)

    def _select_checkpoint(self) -> Optional[tuple[int, str, Path]]:
        """Newest VALID checkpoint for the CURRENT chain, or None.

        A checkpoint file is named by the ledger head hash it summarizes. It is a
        candidate only if that head hash actually appears in THIS chain — then its
        prefix is cryptographically exactly events 1..S (the chain is hash-linked),
        so a stale file from a rewound/divergent history simply never matches. It
        is VALID only if no retraction/redaction event exists at seq > S: those
        kinds retroactively silence/remove events at seq <= S, which the snapshot
        froze, so a later one makes it stale (the CRUX — restore, i.e. a retraction
        with restore=True, counts too). Among valid candidates pick the largest S
        to fold the shortest tail. The chosen file's integrity is verified at
        restore time; a torn snapshot falls back to a full replay.
        """
        ckpt_dir = self._checkpoint_dir()
        if not ckpt_dir.exists():
            return None
        files: dict[str, Path] = {}
        for p in ckpt_dir.glob("*.sqlite3"):
            head = p.stem
            if is_payload_hash(head):   # 64-char lowercase hex — a head-hash shape
                files[head] = p
        if not files:
            return None
        head_seq: dict[str, int] = {}
        last_retro = 0
        for ev in self.ledger.read_all():
            if ev.kind in ("retraction", "redaction"):
                last_retro = ev.seq     # read_all yields in seq order → ends at max
            if ev.hash in files:
                head_seq[ev.hash] = ev.seq
        best: Optional[tuple[int, str, Path]] = None
        for head, seq in head_seq.items():
            if seq < last_retro:
                continue                # a later retraction/redaction invalidated it
            if best is None or seq > best[0]:
                best = (seq, head, files[head])
        return best

    def checkpoint(self) -> Optional[str]:
        """Snapshot the derived index at the current ledger head as a droppable
        cache, so future open()s fold only the tail (spec §6.4, SPEC.md:336).

        Costs NO ledger event — the snapshot is keyed by the current head hash and
        written under <root>/checkpoints/, leaving ledger_head/seq untouched (so no
        head/seq assertion elsewhere can break). Deleting it changes nothing: a
        full replay from the log alone still reproduces identical state (I1).

        The snapshot is the PRE-SWEEP folded state (the sweep is re-run after the
        tail folds on restore). Building it reuses an earlier valid checkpoint when
        present, so making a fresh checkpoint folds only the tail too. Returns the
        head hash checkpointed, or None if the ledger is empty.
        """
        head = self.ledger.head()
        if head == GENESIS:
            return None
        dest = self._checkpoint_dir() / f"{head}.sqlite3"
        if dest.exists():
            return head
        redacted = self._redacted_payloads()
        retracted = self._retracted_actors()
        tmp_dir = Path(tempfile.mkdtemp(prefix="candor-ckpt-"))
        try:
            tmp_index = Index(tmp_dir / "index.sqlite3")
            tmp_index.open()
            start_seq = 0
            cp = self._select_checkpoint()
            if cp is not None and tmp_index.restore_from(cp[2]):
                start_seq = cp[0]
            for ev in self.ledger.read_all():
                if ev.seq <= start_seq:
                    continue
                silenced = ev.actor in retracted and ev.kind != "retraction"
                payload = (None if silenced or ev.payload_hash in redacted
                           else self.ledger.payload(ev.payload_hash))
                apply_mod.apply_event(tmp_index, ev, payload)
            # H6b: snapshot the POST-sweep state so a fast-path open() restores
            # verdicts and re-sweeps only tail-touched facts. Sweep incrementally
            # here too when we reused an earlier (already-swept) checkpoint, so
            # building a fresh checkpoint stays O(tail) on the sweep as well.
            if start_seq > 0:
                touched = [r["fact_id"] for r in tmp_index.query(
                    "SELECT DISTINCT fact_id FROM observations "
                    "WHERE event_seq > ? AND fact_id IS NOT NULL ORDER BY fact_id",
                    (start_seq,))]
                curiosity_mod.resweep(tmp_index, touched)
            else:
                curiosity_mod.sweep(tmp_index)
            tmp_index.commit()
            tmp_index.snapshot_to(dest)
            tmp_index.close()
            return head
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def _redacted_payloads(self) -> set[str]:
        out: set[str] = set()
        for ev in self.ledger.read_all():
            if ev.kind != "redaction":
                continue
            payload = self.ledger.payload(ev.payload_hash)
            if payload:
                out.add(payload["payload_hash"])
        return out

    def _retracted_actors(self) -> set[str]:
        """Actors currently silenced. Folded in sequence order, so a later
        restore reverses an earlier retraction without editing anything."""
        out: set[str] = set()
        for ev in self.ledger.read_all():
            if ev.kind != "retraction":
                continue
            payload = self.ledger.payload(ev.payload_hash)
            if not payload:
                continue
            if payload.get("restore"):
                out.discard(payload["actor"])
            else:
                out.add(payload["actor"])
        return out

    def replay(self) -> str:
        # A forced full-from-genesis fold: replay() is the I1 oracle, so it must
        # ignore the checkpoint cache and re-derive from the log alone.
        self.ledger.close()
        self.ledger.open()
        self.index.reset()
        self._refold(use_checkpoint=False)
        return self.closure_hash()

    # ── closure ──────────────────────────────────────────────────────────────
    def closure(self) -> closure_mod.Closure:
        if self._closure is None:
            self._closure = apply_mod.rebuild_closure(self.index)
            self.index.commit()
        return self._closure

    def closure_hash(self) -> str:
        self.closure()
        return apply_mod.closure_hash(self.index)

    def ledger_head(self) -> str:
        return self.ledger.head()

    # ── writes ───────────────────────────────────────────────────────────────
    def _known_predicates(self) -> dict[str, int]:
        known = {r["pred"]: int(r["arity"])
                 for r in self.index.query("SELECT pred, arity FROM predicates")}
        for row in self.index.query(
                "SELECT body_json FROM candidates WHERE kind='symbol' "
                "AND status='pending'"):
            body = json.loads(row["body_json"])
            known.setdefault(body["pred"], int(body.get("arity", 0)))
        return known

    def assert_(self, stmt: Mapping[str, Any], source: str, actor: str) -> str:
        """§5 assert → candidate_id. Never a fact (I10)."""
        eff_ts = self._now_ms()
        self._check_quota(actor, "candidate", apply_mod.epoch_of(eff_ts))
        proposals = extractor_mod.propose(stmt, self._known_predicates())
        last = ""
        for kind, body in proposals:
            ev = self.ledger.append(
                "assertion", actor,
                {"candidate_kind": kind, "body": body},
                source_ref=source, ts=eff_ts)
            apply_mod.apply_event(self.index, ev, {"candidate_kind": kind, "body": body})
            last = apply_mod.candidate_id_for(ev.seq)
        self.index.commit()
        return last

    def run_gate(self) -> list[dict[str, Any]]:
        """Curiosity sweep (§3.10), then drain candidates through the gate.

        The sweep is a deterministic function of the observed facts (its inputs
        are observations attributed to admitted facts, and an observation only
        attaches to a fact once that fact is admitted — so any new sweep input
        arrives as a new observation event). With the max observation event_seq
        unchanged since the last sweep, the sweep would re-propose byte-identical
        candidates and re-write identical flags: pure churn (M11c). A genuinely
        idle run_gate therefore skips the sweep — appending nothing and paying
        O(1) instead of an O(observations) sweep plus a standing assertion event
        per proposal on every call. The candidate drain still runs, so pending
        candidates from `assert_` are always processed.
        """
        obs_seq = self._max_observation_seq()
        # Δ11: audit admitted guards BEFORE the sweep re-proposes anything, so a
        # demotion is on the books when the memoryless re-proposal reaches the
        # gate in this same call — the re-entry bar sees it, no flap window.
        audit_runs: list[dict[str, Any]] = []
        if obs_seq != self._audit_obs_watermark:
            audit_runs = self._audit_admitted_guards()
            self._audit_obs_watermark = obs_seq
        if obs_seq != self._sweep_obs_watermark:
            for kind, body in curiosity_mod.sweep(self.index):
                ev = self.ledger.append("assertion", "agent:curiosity",
                                        {"candidate_kind": kind, "body": body},
                                        source_ref="curiosity:sweep")
                apply_mod.apply_event(self.index, ev,
                                      {"candidate_kind": kind, "body": body})
            self._sweep_obs_watermark = obs_seq
        runs: list[dict[str, Any]] = list(audit_runs)
        pending = self.index.query(
            "SELECT id, kind, body_json, proposer FROM candidates "
            "WHERE status='pending' ORDER BY event_seq")
        for row in pending:
            body = json.loads(row["body_json"])
            if row["kind"] == "guard":
                # Δ11: a re-proposal of a demoted direction is judged on FRESH
                # evidence — attach the post-demotion record (periphery scores,
                # the gate decides, the decision is recorded; replay folds it
                # without re-judging).
                self._attach_post_demotion_record(body)
            decision = gate_mod.evaluate(self.index, row["id"], row["kind"], body,
                                         row["proposer"])
            gate_run_id = apply_mod.gate_run_id_for(self.ledger.seq() + 1)
            payload = decision.as_payload()
            payload["gate_run_id"] = gate_run_id
            ev = self.ledger.append("admission", row["proposer"], payload)
            apply_mod.apply_event(self.index, ev, payload)
            if decision.status == "admitted" and decision.candidate_kind == "alias":
                alias_payload = dict(decision.body)
                alias_payload["gate_run_id"] = gate_run_id
                aev = self.ledger.append("alias", row["proposer"], alias_payload)
                apply_mod.apply_event(self.index, aev, alias_payload)
            runs.append({
                "gate_run_id": gate_run_id, "candidate_id": row["id"],
                "candidate_kind": decision.candidate_kind,
                "status": decision.status, "failing_step": decision.failing_step,
                "reason": decision.reason,
            })
        self._closure = None
        self.index.commit()
        return runs

    def _attach_post_demotion_record(self, body: dict[str, Any]) -> None:
        """Δ11: when a guard candidate matches a previously demoted direction,
        score that direction on the observations AFTER the latest demotion and
        attach it as body["post_demotion"] (None when nothing is scorable yet).
        The gate's re-entry bar judges THIS record instead of the full-history
        holdout the sweep computed — the flap-proof evidence."""
        guards = (body.get("body") or {}).get("guards") or []
        target = body.get("target_fact")
        ck = body.get("conditioning_key")
        if not guards or not target or not ck:
            return
        value = guards[0].get("value")
        at: Optional[int] = None
        for r in self.index.query(
                "SELECT body_json, reason FROM candidates "
                "WHERE kind='guard' AND status='demoted' ORDER BY event_seq"):
            prior = json.loads(r["body_json"])
            pguards = (prior.get("body") or {}).get("guards") or []
            if (prior.get("target_fact") == target
                    and prior.get("conditioning_key") == ck
                    and pguards and pguards[0].get("value") == value):
                try:
                    at = int(json.loads(r["reason"] or "{}").get("at", 0))
                except (ValueError, TypeError):
                    at = 0
        if at is None:
            return
        score = curiosity_mod.prospective_guard_score(self.index, body, at)
        body["post_demotion"] = (
            {"hits": score[0], "misses": score[1]} if score else None)

    def _audit_admitted_guards(self) -> list[dict[str, Any]]:
        """Δ11 — the prospective audit: admitted guards must keep paying rent.

        The entry holdout validated a guard once, retrospectively, on data that
        existed at proposal time. This scores every admitted guard on the
        observations that arrived AFTER its admission — predictions it actually
        risked — and demotes it through the ledger when either signal fires:

          * REVERSAL: the post-admission direction is wrong at the §3.4
            hysteresis bar (`demotion_warranted` over admission-vs-against
            log-odds) — the condition flipped under it;
          * STALENESS: the direction stops beating chance (hits <= misses) on
            STALE_AUDIT_FACTOR times the audit floor — removal on a null effect
            needs strictly more evidence than entry did.

        The demotion event carries the scored record; the fold marks the rule
        'candidate' (out of the closure and the read paths) and the candidate
        row 'demoted' with the against-evidence, which the gate's re-entry bar
        then holds future re-proposals to. Trusted-side decision over an
        untrusted-side score, appended and folded like every structural change
        — replay reproduces it without re-judging (§3.4).
        """
        demoted: list[dict[str, Any]] = []
        rows = self.index.query(
            "SELECT id, gate_run_id, body_json FROM candidates "
            "WHERE kind='guard' AND status='admitted' ORDER BY event_seq")
        for row in rows:
            gate_run = row["gate_run_id"] or ""
            try:
                admitted_seq = int(gate_run.split(":", 1)[1])
            except (IndexError, ValueError):
                continue
            body = json.loads(row["body_json"])
            score = curiosity_mod.prospective_guard_score(
                self.index, body, admitted_seq)
            if score is None:
                continue
            hits, misses = score
            holdout = body.get("holdout") or {}
            # Evidence in nats (gate.direction_evidence): the admission record's
            # support for the direction vs the post-admission record's support
            # for its INVERSE — both grow with sample size, so the §3.4
            # hysteresis compares like with like.
            admission = gate_mod.direction_evidence(
                int(holdout.get("hits", 0)), int(holdout.get("misses", 0)))
            against = gate_mod.direction_evidence(misses, hits)
            reversal = gate_mod.demotion_warranted(admission, against)
            stale = (hits <= misses
                     and hits + misses >= gate_mod.STALE_AUDIT_FACTOR
                     * curiosity_mod.MIN_AUDIT_OBS)
            if not (reversal or stale):
                continue
            why = "direction reversed post-admission" if reversal else \
                "stopped beating chance on twice the entry evidence"
            payload = {
                "target_kind": "rule",
                "target_id": f"rule:{admitted_seq}",
                "candidate_id": row["id"],
                "scored": {"hits": hits, "misses": misses},
                "reason": f"prospective audit: {why} "
                          f"({hits} hits / {misses} misses)",
            }
            ev = self.ledger.append("demotion", "agent:curiosity", payload,
                                    source_ref="curiosity:prospective-audit")
            apply_mod.apply_event(self.index, ev, payload)
            demoted.append({
                "gate_run_id": None, "candidate_id": row["id"],
                "candidate_kind": "guard", "status": "demoted",
                "failing_step": None, "reason": payload["reason"],
            })
        if demoted:
            self._closure = None
        return demoted

    def _max_observation_seq(self) -> int:
        """Largest observation event_seq in the index (0 if none). The sweep's
        watermark: it advances only when a new observation is applied, never on
        run_gate's own admission/assertion appends."""
        row = self.index.one("SELECT MAX(event_seq) AS m FROM observations")
        return int(row["m"]) if row and row["m"] is not None else 0

    def set_actor_quota(self, actor: str, obs_per_epoch: Optional[int] = None,
                        cand_per_epoch: Optional[int] = None) -> None:
        """Provision an actor's §3.12 quotas (operational config, spec §2).

        The bound stays enforced at the API boundary; only the configured limit
        changes. Quotas are not part of the replay-determinism hash — they are
        deployment configuration, like the fsync policy.
        """
        apply_mod.ensure_actor(self.index, actor)
        if obs_per_epoch is not None:
            self.index.execute("UPDATE actors SET obs_quota_per_epoch=? WHERE name=?",
                               (int(obs_per_epoch), actor))
        if cand_per_epoch is not None:
            self.index.execute("UPDATE actors SET cand_quota_per_epoch=? WHERE name=?",
                               (int(cand_per_epoch), actor))
        self.index.commit()

    @staticmethod
    def _now_ms() -> int:
        """Wall-clock event time in ms — matches ledger.append's own default."""
        return int(time.time() * 1000)

    def _check_quota(self, actor: str, kind: str, epoch: int) -> None:
        """§3.12 flooding bound, evaluated for the epoch the impending event
        falls in. The caller derives `epoch` from the event's timestamp and
        stamps that same ts on the append, so the check and the fold-time bump
        agree on the bucket even at an epoch boundary."""
        limit = apply_mod.quota_limit(self.index, actor, kind)
        used = apply_mod.quota_used(self.index, actor, kind, epoch)
        if used >= limit:
            self._health_events.append({
                "kind": "quota_exhausted", "actor": actor, "quota_kind": kind,
                "epoch": epoch, "used": used, "limit": limit})
            apply_mod.diagnostic(self.index, 0, "quota_exhausted",
                                 {"actor": actor, "quota_kind": kind,
                                  "epoch": epoch, "limit": limit})
            self.index.commit()
            raise QuotaExceeded(
                f"{actor} exhausted its {kind} quota for epoch {epoch} "
                f"({used}/{limit})")

    def set_authz(self, policy: Optional[Callable[[str, str], bool]]) -> None:
        """Install (or clear) an authorization policy for privileged writes (M3).

        `policy(principal, op) -> bool` is consulted before every privileged
        write — pin, redact, retract_source, register_oracle, set_reliability —
        with the caller-supplied authority label and the operation name; a
        falsy return raises `Unauthorized` before anything is appended. Passing
        `None` restores the default advisory posture, in which `authority` is an
        attribution label and access control is the embedding app's job (the
        trust boundary is the process; see SECURITY.md).

        The policy is runtime configuration, not ledger state: it never enters
        the closure hash, and replay of an existing ledger never re-checks it.
        """
        self._authz = policy

    def _authorize(self, principal: str, op: str) -> None:
        """Gate a privileged write. A no-op unless a policy is registered."""
        if self._authz is not None and not self._authz(principal, op):
            # Reject before any ledger append or index mutation; record the
            # attempt in the in-memory health log only (audit, not replay state).
            self._health_events.append(
                {"kind": "unauthorized", "principal": principal, "op": op})
            raise Unauthorized(f"{principal!r} is not authorized to {op}")

    def observe(self, stmt: Mapping[str, Any], outcome: Optional[bool] = None,
                ctx: Optional[Mapping[str, str]] = None, actor: str = "",
                value: Optional[str] = None,
                confidence: Optional[float] = None,
                ts: Optional[int] = None) -> int:
        """Record an observation (§3.7).

        `value` (categorical C1, §1.4) is the realised category for a categorical
        fact. Existing callers pass `outcome` and leave `value=None` — the
        UNCHANGED crisp/frequency path. For a categorical fact the caller passes
        `value="captcha"` and `outcome` is ignored. Which field is authoritative
        is decided at FOLD time by the fact's stmt_type, not here (so an
        observation arriving before its fact is admitted still routes correctly on
        replay). The value rides in the ledger payload for audit, exactly as raw
        `confidence` does for graded observations.
        """
        # Fix the event time up front so the quota check and the fold-time bump
        # agree on the epoch; ts=None keeps the ingest wall clock (§3.1), and a
        # historical replay passes the real event time (so a located changepoint
        # gets the real valid_to).
        eff_ts = ts if ts is not None else self._now_ms()
        self._check_quota(actor, "observation", apply_mod.epoch_of(eff_ts))
        payload = {"stmt": {"pred": stmt["pred"], "args": list(stmt["args"])},
                   "outcome": None if outcome is None else bool(outcome),
                   "value": value, "ctx": dict(ctx or {}),
                   "grade": reliability_mod.grade_of(confidence),
                   "confidence": confidence}
        ev = self.ledger.append("observation", actor, payload,
                                context_sig=context_signature(ctx), ts=eff_ts)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()
        return ev.seq

    def observe_batch(self, obs: Sequence[Sequence[Any]]) -> list[int]:
        """Batch observe. Each tuple is (stmt, outcome, ctx, actor) or, to stamp
        a historical event time, (stmt, outcome, ctx, actor, ts)."""
        out: list[int] = []
        for item in obs:
            stmt, outcome, ctx, actor = item[0], item[1], item[2], item[3]
            ts = item[4] if len(item) > 4 else None
            out.append(self.observe(stmt, outcome, ctx, actor, ts=ts))
        return out

    def pin(self, target_id: str, polarity: str, reason: str, authority: str) -> int:
        self._authorize(authority, "pin")
        # Validate at the boundary, before the ledger append (C3): the index's
        # pins.polarity CHECK would otherwise reject the event only after it was
        # already in the chain, bricking every future replay.
        if polarity not in ("+", "-"):
            raise ValueError(f"pin polarity must be '+' or '-', got {polarity!r}")
        payload = {"target_kind": "fact", "target_id": target_id,
                   "polarity": polarity, "reason": reason, "authority": authority}
        ev = self.ledger.append("pin", authority, payload)
        apply_mod.apply_event(self.index, ev, payload)
        self._closure = None
        self.index.commit()
        return ev.seq

    def supersede(self, target_id: str, reason: str,
                  actor: str = "human:operator") -> int:
        payload = self._supersede_payload(str(target_id), reason)
        ev = self.ledger.append("supersede", actor, payload)
        apply_mod.apply_event(self.index, ev, payload)
        self._closure = None
        self.index.commit()
        return ev.seq

    def _supersede_payload(self, target_id: str, reason: str) -> dict[str, Any]:
        """Resolve what is being superseded: an event, a fact, a rule, a pin."""
        if target_id.isdigit():
            row = self.index.one("SELECT kind, payload_hash FROM events WHERE seq=?",
                                 (int(target_id),))
            if row is not None and row["kind"] == "alias":
                payload = self.ledger.payload(row["payload_hash"]) or {}
                return {"target_kind": "alias_event", "target_id": target_id,
                        "reason": reason,
                        "alias": {"canonical": payload.get("canonical"),
                                  "alias": payload.get("alias")}}
            return {"target_kind": "event", "target_id": target_id, "reason": reason}
        if target_id.startswith("pin:"):
            kind = "pin"
        elif target_id.startswith("rule:"):
            kind = "rule"
        elif target_id.startswith("con:"):
            kind = "constraint"
        elif target_id.startswith("cand:"):
            kind = "candidate"
        else:
            kind = "fact"
        return {"target_kind": kind, "target_id": target_id, "reason": reason}

    def retract_source(self, actor: str, reason: str, restore: bool = False,
                       authority: str = "human:operator") -> int:
        """Silence one source. Every number it ever moved recomputes without it.

        This — not `redact` — is how you recover from a bad source. Redaction
        is keyed on a *content-addressed payload*, which by construction has no
        actor in it: two sources reporting the same outcome on the same
        statement in the same context share one payload, so redacting a liar's
        hash also destroys the honest reports that agreed with it. Retraction
        is keyed on the actor, so its blast radius is exactly one source.

        Append-only and reversible: `restore=True` un-silences, and the whole
        history stays in the chain either way.
        """
        self._authorize(authority, "retract_source")
        payload = {"actor": actor, "reason": reason, "restore": bool(restore)}
        ev = self.ledger.append("retraction", authority, payload)
        self.index.reset()
        self._refold()
        self.closure()
        return ev.seq

    def redaction_scope(self, payload_hash: str) -> dict[str, Any]:
        """Who would lose data if this payload were redacted (§3.13 blast radius).

        Payloads are content-addressed and deduplicated, so a hash can be
        shared by any number of actors. Call this before `redact` when the
        intent is to purge a *source* rather than a piece of content — or use
        `retract_source`, which cannot over-reach.
        """
        rows = self.index.query(
            "SELECT actor, kind FROM events WHERE payload_hash=?", (payload_hash,))
        actors = sorted({r["actor"] for r in rows})
        return {"payload_hash": payload_hash, "events": len(rows),
                "actors": actors, "shared": len(actors) > 1}

    def redact(self, payload_hash: str, authority: str = "human:operator") -> int:
        """Purge one payload's CONTENT everywhere it appears.

        Scoped to content, not to a source: every event carrying this hash
        loses its payload, whoever wrote it. See `redaction_scope` for the
        blast radius, and `retract_source` to silence a single actor instead.

        `authority` names the principal requesting the purge; it defaults to the
        historical `human:operator` label and gates the write when an
        authorization policy is installed (M3). The recorded redaction event
        actor is unchanged, so the ledger is byte-identical for existing callers.
        """
        self._authorize(authority, "redact")
        # Reject a bad hash at the boundary, before appending anything (M4):
        # the argument flows into `cas_dir / f"{payload_hash}.json"`, so a value
        # with `..` in it would unlink a file outside the store.
        if not is_payload_hash(payload_hash):
            raise ValueError(
                "payload_hash must be a 64-char lowercase sha256 hex digest, "
                f"got {payload_hash!r}")
        scope = self.redaction_scope(payload_hash)
        if scope["shared"]:
            apply_mod.diagnostic(self.index, 0, "redaction_shared_payload", scope)
            self._health_events.append({"kind": "redaction_shared_payload", **scope})
        payload = {"payload_hash": payload_hash}
        ev = self.ledger.append("redaction", "human:operator", payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.ledger.delete_payload(payload_hash)
        # Redaction implies exclusion: downstream state is recomputed without it.
        self.index.reset()
        self._refold()
        self.closure()
        return ev.seq

    # ── claims & settlement (§3.8) ───────────────────────────────────────────
    def claim(self, stmt: Mapping[str, Any], frame: str, criterion: str,
              due: int) -> str:
        # Validate at the boundary, before the ledger append (C3): the index's
        # claims.frame CHECK would otherwise reject the event only after it was
        # already in the chain, bricking every future replay.
        if frame not in ("internal", "external"):
            raise ValueError(
                f"claim frame must be 'internal' or 'external', got {frame!r}")
        settlement, verifier_id = self._triage(stmt, criterion)
        if settlement == "unsettleable":
            return REFUSED
        pred = self.predict(stmt, budget=10_000)
        claim_id = f"claim:{self.ledger.seq() + 1}"
        base = {
            "claim_id": claim_id,
            "stmt": {"pred": stmt["pred"], "args": list(stmt["args"])},
            "frame": frame, "settlement": settlement, "criterion": criterion,
            "verifier_id": verifier_id, "due": due,
            "certainty_class": self._certainty_class(settlement, verifier_id),
        }
        if isinstance(pred, CategoricalPrediction):
            # A categorical claim is a DISTRIBUTION, not a scalar p (design §4.1):
            # freeze the full C2 predictive into the payload (snapshot-pinned, I8)
            # so resolution can score −log P(v*) — including the reserved unknown
            # slice for a never-seen v*. Distinct predictor_class ⇒ never pools
            # with binary calibration (I9). Leaf query ⇒ no proof-sensitivity.
            payload = {
                **base,
                "predicted_p": None, "ci_lo": None, "ci_hi": None,
                "predicted_dist": {
                    "values": {v: s.p for v, s in pred.values.items()},
                    "unknown": pred.unknown.p},
                "model_snapshot": pred.snapshot_id,
                "predictor_class": calibration_mod.CATEGORICAL_PREDICTOR_CLASS,
                "sensitivity": {},
            }
        else:
            payload = {
                **base,
                "predicted_p": pred.p, "ci_lo": pred.ci[0], "ci_hi": pred.ci[1],
                "model_snapshot": pred.snapshot_id,
                "predictor_class": calibration_mod.DEFAULT_PREDICTOR_CLASS,
                "sensitivity": pred.sensitivity,
            }
        ev = self.ledger.append("claim", "agent:planner", payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()
        return claim_id

    def _triage(self, stmt: Mapping[str, Any],
                criterion: str) -> tuple[str, Optional[str]]:
        if criterion in ("", None, "none", "unsettleable"):
            return "unsettleable", None
        # An explicitly named, registered oracle outranks the closure. §3.8 says
        # plainly that self-consistency is not truth: if a caller has gone to the
        # trouble of constructing an external verifier, settling the claim
        # internally instead would inflate the entailed share of the
        # external-settled ratio that the same section tells us to watch.
        if self.index.one("SELECT id FROM oracles WHERE id=?", (criterion,)):
            return "tool_decidable", criterion
        derived = self.derive(stmt, budget=10_000)
        if derived.status == "proof":
            return "entailed", "verifier:closure"
        if criterion.startswith("tool:") or criterion.startswith("verifier:"):
            return "tool_decidable", criterion
        return "observation_pending", f"verifier:observation({criterion})"

    def _certainty_class(self, settlement: str, verifier_id: Optional[str]) -> str:
        if settlement == "entailed":
            return "certain"
        row = self.index.one("SELECT kind FROM oracles WHERE id=?", (verifier_id,))
        if row is not None and row["kind"] == "deterministic_total":
            return "certain"
        return "estimated"

    def register_oracle(self, oracle_id: str, kind: str, impl_ref: str,
                        code_hash: str, env_hash: str,
                        authority: str = "human:operator") -> None:
        """Register a pre-validated external oracle, through the ledger.

        Synthesized verifiers earn their oracle row through the gate's sandbox
        step; an externally validated oracle enters as a human-authorized
        admission event instead — same append path, same replayability. A
        direct SQLite write here would vanish on replay (the test that caught
        exactly that lives in tests/unit/test_two_coin.py).
        """
        self._authorize(authority, "register_oracle")
        payload = {
            "candidate_id": f"cand:oracle:{oracle_id}",
            "candidate_kind": "verifier", "status": "admitted",
            "failing_step": None, "reason": "external registration",
            "body": {"oracle_id": oracle_id, "kind": kind, "entry": impl_ref,
                     "code_hash": code_hash, "env_hash": env_hash},
        }
        ev = self.ledger.append("admission", authority, payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()

    def resolve(self, claim_id: str, outcome: Optional[bool] = None,
                value: Optional[str] = None,
                verifier_code_hash: str = "", env_hash: str = "") -> int:
        """Settle a claim. Crisp/frequency claims settle against a boolean
        `outcome`; a categorical claim settles against the realised `value` (v*):
        the verifier reports which value of the open set actually occurred, and
        the surprisal −log P_frozen(v*) is scored against the distribution frozen
        at claim time (design §4)."""
        row = self.index.one("SELECT * FROM claims WHERE id=?", (claim_id,))
        if row is None:
            raise KeyError(f"unknown claim {claim_id!r}")
        oracle_kind = None
        if row["verifier_id"]:
            orow = self.index.one("SELECT kind FROM oracles WHERE id=?",
                                  (row["verifier_id"],))
            oracle_kind = orow["kind"] if orow else None
        if row["predicted_dist_json"] is not None:
            return self._resolve_categorical(
                row, claim_id, value, oracle_kind, verifier_code_hash, env_hash)
        predicted = float(row["predicted_p"] if row["predicted_p"] is not None else 0.5)
        sensitivity = {
            r["fact_id"] or r["rule_id"]: float(r["sensitivity"])
            for r in self.index.query(
                "SELECT rule_id, fact_id, sensitivity FROM proof_steps WHERE claim_id=?",
                (claim_id,))
            if (r["fact_id"] or r["rule_id"])
        }
        payload = {
            "claim_id": claim_id, "outcome": bool(outcome),
            "surprisal": calibration_mod.surprisal(predicted, bool(outcome)),
            "sensitivity": sensitivity,          # full vector, always logged (§4.4)
            "blame_target": self._blame_target(sensitivity),
            "verifier_code_hash": verifier_code_hash,
            "env_hash": env_hash,
            "oracle_kind": oracle_kind,
        }
        ev = self.ledger.append("resolution", "verifier:harness", payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()
        # Δ12: a conjecture claim that settled TRUE is a VALIDATED postulate —
        # implement it by asserting the statement as an ordinary fact candidate
        # through the gate (I10: through, never around). A false settlement
        # implements nothing; either way the analogy engine's calibration curve
        # was just scored above (I9, its own predictor class).
        if (row["predictor_class"] == calibration_mod.CONJECTURE_PREDICTOR_CLASS
                and bool(outcome)):
            stmt = json.loads(row["stmt_json"])
            self.assert_({"pred": stmt["pred"], "args": stmt["args"],
                          "stmt_type": "crisp"},
                         source=f"conjecture:{claim_id}",
                         actor="agent:conjecture")
        return ev.seq

    def _resolve_categorical(self, row: Any, claim_id: str,
                             value: Optional[str], oracle_kind: Optional[str],
                             verifier_code_hash: str, env_hash: str) -> int:
        """Settle a categorical claim against the realised value v* (design §4.1).

        Surprisal = −log P_frozen(v*), read off the distribution frozen at claim
        time. If v* was a SEEN value it scores against that value's slice; if v*
        was NEVER seen at claim time it scores against the reserved unknown mass —
        FINITE, not infinite. P(v*) also feeds the categorical calibration diagram
        (recorded in _apply_resolution under the distinct predictor_class, I9),
        and v* rides the payload for audit."""
        if value is None:
            raise ValueError(
                "a categorical claim resolves against a realised value "
                "(pass value=...), not a boolean outcome")
        frozen = json.loads(row["predicted_dist_json"])
        realized = str(value)
        # The unseen slice is exactly what makes this well-defined for a value
        # never observed at claim time (design §4.1) — not a zero-probability
        # infinite-surprisal blow-up.
        p_star = frozen["values"].get(realized)
        if p_star is None:
            p_star = frozen["unknown"]
        payload = {
            "claim_id": claim_id,
            "outcome": True,                     # the realised value did occur
            "realized_value": realized,          # audit — which value settled
            "surprisal": calibration_mod.surprisal(float(p_star), True),
            "predicted_p": float(p_star),        # P(v*), for calibration (I9)
            "verifier_code_hash": verifier_code_hash,
            "env_hash": env_hash,
            "oracle_kind": oracle_kind,
        }
        ev = self.ledger.append("resolution", "verifier:harness", payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()
        return ev.seq

    def _blame_target(self, sensitivity: Mapping[str, float]) -> Optional[str]:
        """§4.4: integer blame to the argmax-sensitivity *eligible* component."""
        best, best_s = None, -1.0
        for comp, s in sorted(sensitivity.items()):
            if not self._blame_eligible(comp):
                continue
            if s > best_s:
                best, best_s = comp, s
        return best

    def _blame_eligible(self, component: str) -> bool:
        if component.startswith("rule:"):
            row = self.index.one("SELECT numeric FROM rules WHERE id=?", (component,))
            return row is not None and row["numeric"] != "frozen"
        row = self.index.one("SELECT kind, numeric FROM facts WHERE id=?", (component,))
        if row is None:
            return False
        if row["kind"] == "definitional" or row["numeric"] == "frozen":
            return False
        # What remains is a stored fact that was admitted (admitted_by_event is
        # always set on insert), non-definitional and not frozen — a base
        # admitted fact, which is blame-eligible. Facts DERIVED through a rule
        # are never stored here (they live in the read-time closure), so the
        # "exact-derived facts are ineligible" rule already holds by
        # construction — there is nothing further to exclude.
        return True

    # ── reads ────────────────────────────────────────────────────────────────
    def recall(self, query: str, budget: int,
               actor: str = "agent:reader") -> list[dict[str, Any]]:
        """Side-stream logged; no effect on any committed number (I2)."""
        return self.retriever.recall(query, budget, actor)

    def derive(self, goal: Mapping[str, Any], budget: int) -> DeriveOutcome:
        pred = goal["pred"]
        args = tuple(facts_mod.canonical_args(self.index, pred, list(goal["args"])))
        clo = self.closure()
        rules = self._rules()
        outcome = closure_mod.backward(pred, args, clo, rules, budget)
        if outcome.proved and outcome.proof is not None:
            # Only genuinely base atoms may be cited without a rule (§3.6): a
            # rule-derived conclusion must present its rule to the kernel.
            kernel_mod.check(outcome.proof, set(clo.base), {r.id: r for r in rules})
            quality = kernel_mod.quality(outcome.proof, self._flagged_facts(),
                                         self._narrow_facts())
            return DeriveOutcome("proof", outcome.proof, True, quality)
        if not outcome.exhausted:
            return DeriveOutcome("budget_exceeded", None, False)
        return DeriveOutcome("not_entailed", None, True)

    def _rules(self) -> list[closure_mod.Rule]:
        return [closure_mod.Rule.parse(r["id"], r["head_json"], r["body_json"],
                                       int(r["specificity"]))
                for r in self.index.query(
                    "SELECT * FROM rules WHERE structural='admitted' "
                    "ORDER BY specificity DESC, id")]

    def _flagged_facts(self) -> set[str]:
        return {r["id"] for r in self.index.query(
            "SELECT id FROM facts WHERE dispersion_flag=1")}

    def _narrow_facts(self) -> set[str]:
        return {r["id"] for r in self.index.query(
            "SELECT id FROM facts WHERE breadth_class='narrow'")}

    def conjecture(self, goal: Mapping[str, Any], sim_budget: float,
                   commit: bool = False,
                   due: Optional[int] = None) -> list[dict[str, Any]]:
        """Analogical conjectures for `goal` (§4.3, I4) — and, with `commit`,
        the postulate→validate→implement loop over them (Δ12).

        `commit=False` (the default) is the read-only path, byte-identical to
        before: soft edges propose, nothing is appended, nothing moves.

        `commit=True` files each conjecture as a CLAIM attributed to
        `agent:conjecture`: predicted_p is the analog's own earned probability
        (`predict(via).p` — the analogy TRANSFERS an audited number, similarity
        is not a probability), under the distinct `conjecture/v1` predictor
        class so the analogy engine's calibration curve never pools with the
        WMC engine's (I9). Settling the claim (`resolve`) scores that curve —
        the engine's track record is measured, not presumed — and a TRUE
        settlement auto-asserts the goal as an ordinary fact candidate through
        the gate (I10: never a fact directly). A conjecture with an unresolved
        claim already on the books is not re-filed; it carries the existing
        claim_id. Conjectures whose analog is categorical are proposed but not
        committed (a distribution is not a transferable scalar).
        """
        signatures = self._signatures()
        neighbours = conjecture_mod.neighbourhood(goal["pred"], signatures, sim_budget)
        known = {(p, a) for p, a in self.closure().atoms}
        out = conjecture_mod.conjectures(goal, neighbours, known)
        if not commit:
            return out
        for c in out:
            stmt = {"pred": c["goal"]["pred"], "args": list(c["goal"]["args"])}
            stmt_json = canon_json(stmt)
            existing = self.index.one(
                "SELECT id FROM claims WHERE predictor_class=? AND stmt_json=? "
                "AND resolved_ts IS NULL ORDER BY id LIMIT 1",
                (calibration_mod.CONJECTURE_PREDICTOR_CLASS, stmt_json))
            if existing is not None:
                c["claim_id"] = existing["id"]
                continue
            via_pred = self.predict(c["via"], budget=10_000)
            if not isinstance(via_pred, PredictOutcome):
                continue                    # categorical analog: nothing to transfer
            claim_id = f"claim:{self.ledger.seq() + 1}"
            payload = {
                "claim_id": claim_id, "stmt": stmt,
                "frame": "internal", "settlement": "observation_pending",
                "criterion": f"conjecture:{c['via']['pred']}",
                "verifier_id": "verifier:observation(conjecture)",
                "due": due, "certainty_class": "estimated",
                "predicted_p": via_pred.p,
                "ci_lo": via_pred.ci[0], "ci_hi": via_pred.ci[1],
                "model_snapshot": via_pred.snapshot_id,
                "predictor_class": calibration_mod.CONJECTURE_PREDICTOR_CLASS,
                "sensitivity": {},
                # audit trail: what licensed the transfer, and at what budget
                "conjecture": {"via": c["via"], "sim": c["sim"],
                               "caveats": c["caveats"]},
            }
            ev = self.ledger.append("claim", "agent:conjecture", payload)
            apply_mod.apply_event(self.index, ev, payload)
            c["claim_id"] = claim_id
        self.index.commit()
        return out

    def _signatures(self) -> dict[str, dict[str, float]]:
        firings: list[tuple[str, int, str]] = []
        for rule in self._rules():
            for pos, arg in enumerate(rule.head.args):
                if not closure_mod.is_var(arg):
                    firings.append((rule.id, pos, rule.head.pred))
            for lit in rule.body:
                for pos, arg in enumerate(lit.args):
                    firings.append((rule.id, pos, lit.pred))
        preds = {r["pred"] for r in self.index.query("SELECT DISTINCT pred FROM facts")}
        out: dict[str, dict[str, float]] = {}
        for pred in sorted(preds):
            symbols = facts_mod.alias_closure(self.index, pred)
            co_derived = [p for p, _ in self.closure().atoms if p in symbols]
            out[pred] = conjecture_mod.signature(pred, firings, co_derived)
        return out

    # ── prediction (§3.9) ────────────────────────────────────────────────────
    def predict(self, stmt: Mapping[str, Any], budget: int
                ) -> "PredictOutcome | CategoricalPrediction":
        out = self._predict_with(self.index, self.closure(), stmt, budget,
                                 self._calib, self.ledger.head())
        # A categorical prediction is a distribution, not a constrained WMC world,
        # so it carries no rejection_rate; leave the last-seen scalar rate intact.
        if isinstance(out, PredictOutcome):
            self._last_rejection_rate = out.rejection_rate
        return out

    def predict_at(self, stmt: Mapping[str, Any], snapshot_id: str
                   ) -> "PredictOutcome | CategoricalPrediction":
        """I8: re-run a prediction at its recorded ledger position, pinned map."""
        snap = calibration_mod.parse_snapshot(snapshot_id)
        head = snap["ledger_head"]
        if head == self.ledger.head():
            return self.predict(stmt, budget=10_000)
        tmp_dir = Path(tempfile.mkdtemp(prefix="candor-snapshot-"))
        tmp_index = Index(tmp_dir / "index.sqlite3")
        try:
            tmp_index.open()
            events = list(self.ledger.read_all())
            # A genesis head predates every event, so its snapshot folds NOTHING
            # (cutoff=0, and every event seq is ≥1). The old code left cutoff=None
            # for genesis and then folded the ENTIRE log — the opposite of empty.
            if head == "0" * 64:
                cutoff = 0
            else:
                cutoff = None
                for ev in events:
                    if ev.hash == head:
                        cutoff = ev.seq
                        break
                if cutoff is None:
                    raise KeyError("snapshot ledger head is not in this chain")
            # Reproduce the fold exactly as _refold does: silence retracted
            # sources and exclude redacted payloads, or the snapshot recomputes a
            # different number than the one it recorded (I8 — a retracted source
            # would otherwise speak again).
            redacted = self._redacted_payloads()
            retracted = self._retracted_actors()
            for ev in events:
                if ev.seq > cutoff:
                    break
                silenced = ev.actor in retracted and ev.kind != "retraction"
                payload = (None if silenced or ev.payload_hash in redacted
                           else self.ledger.payload(ev.payload_hash))
                apply_mod.apply_event(tmp_index, ev, payload)
            # The curiosity sweep is a deterministic function of the folded
            # observations; _refold runs it, so predict_at must too or it drops
            # the under_specified / narrow caveats the live prediction carried.
            curiosity_mod.sweep(tmp_index)
            clo = apply_mod.rebuild_closure(tmp_index)
            tmp_index.commit()
            calib = calibration_mod.IsotonicMap.from_json(snap.get("calib_map"))
            if calib.hash != snap["calib_map_hash"]:
                calib = self._calib if self._calib.hash == snap["calib_map_hash"] \
                    else calibration_mod.IsotonicMap()
            return self._predict_with(tmp_index, clo, stmt, 10_000, calib, head)
        finally:
            # Close on EVERY path (M11a): the success path used to be the only
            # place tmp_index.close() ran, so any exception in the fold/predict
            # leaked its 3 sqlite fds (db/-wal/-shm). Closing here also lets the
            # rmtree succeed where an open handle would block unlink.
            tmp_index.close()
            shutil.rmtree(tmp_dir, ignore_errors=True)

    def _predict_with(self, idx: Index, clo: closure_mod.Closure,
                      stmt: Mapping[str, Any], budget: int,
                      calib: calibration_mod.IsotonicMap,
                      ledger_head: str) -> "PredictOutcome | CategoricalPrediction":
        pred = stmt["pred"]
        args = facts_mod.canonical_args(idx, pred, list(stmt["args"]))
        # Categorical facts are LEAF QUERIES (design §3, decision 3): predict
        # returns a full CategoricalPrediction distribution, never a scalar
        # PredictOutcome, so branch BEFORE building the WMC problem. Everything
        # from `problem = ...` down is the scalar path, byte-for-byte unchanged
        # (additivity §6): no categorical code runs for a non-categorical fact.
        fid = facts_mod.lookup(idx, pred, args) or fact_key(pred, args)
        strow = idx.one("SELECT stmt_type FROM facts WHERE id=?", (fid,))
        if strow is not None and strow["stmt_type"] == "categorical":
            return self._predict_categorical(idx, fid, calib, ledger_head)
        problem = self._build_problem(idx, clo, pred, args)
        outcome = predict_mod.run(problem, budget)
        p = calib.apply(outcome.p)
        ci = (calib.apply(outcome.ci[0]), calib.apply(outcome.ci[1]))
        snapshot = calibration_mod.snapshot_id(ledger_head, calib.hash)
        return PredictOutcome(p, ci, dict(outcome.channels),
                              dict(outcome.sensitivity), outcome.mpe,
                              outcome.caveats, snapshot, outcome.rejection_rate)

    def _predict_categorical(self, idx: Index, fact_id: str,
                             calib: calibration_mod.IsotonicMap,
                             ledger_head: str) -> CategoricalPrediction:
        """The categorical leaf-query path (design §2.4). Composes the CRP
        predictive over the per-value counts and wraps it with the snapshot id
        (which folds in the concentration alpha, I8) and read-time caveats. The
        C3 isotonic recalibration of a categorical distribution is future work, so
        `calib` only feeds the snapshot id here, not the probabilities."""
        post = counts_mod.category_posterior(idx, fact_id,
                                             counts_mod.CATEGORICAL_ALPHA)
        snapshot = calibration_mod.categorical_snapshot_id(
            ledger_head, calib.hash, counts_mod.CATEGORICAL_ALPHA)
        caveats: set[str] = set()
        if post.total_observations == 0:
            # Admitted but never observed: the whole predictive mass is unknown.
            caveats.add("no_observations")
        if self._regime_mixed(idx, fact_id):
            caveats.add("regime_mixed")                # Δ13, as on the scalar path

        # C4 (design §3): surface the value distribution CONDITIONED on any key a
        # curiosity guard discovered conditions this fact on. Read the fact's own
        # observations + recorded context and run the §2 CRP predictive per context
        # group (its own unknown slice) plus a __residual__ group for obs missing
        # the key. Which keys to surface is driven by the SAME dispersion→guard
        # flow the binary path uses (§3), not new plumbing.
        obs = self._categorical_observations(idx, fact_id)
        # The under-specified caveat keys off what the AGENT recorded; the Δ10
        # derived frames ride the same dicts but must not trip it.
        recorded_keys = {k for ctx, _ in obs for k in ctx
                         if not curiosity_stats_mod.is_derived(k)}
        cond_keys: list[str] = []
        seen_ck: set[str] = set()
        for r in idx.query(
                "SELECT body_json FROM candidates WHERE kind='guard' "
                "AND status='admitted' ORDER BY event_seq"):
            body = json.loads(r["body_json"])
            if body.get("target_fact") != fact_id:
                continue
            ck = body.get("conditioning_key")
            if ck is not None and ck not in seen_ck:
                seen_ck.add(ck)
                cond_keys.append(ck)
        by_context: dict[str, dict[str, dict[str, Any]]] = {}
        for key in cond_keys:
            if any(key in ctx for ctx, _ in obs):
                by_context[key] = self._categorical_context_breakdown(
                    obs, key, counts_mod.CATEGORICAL_ALPHA)
        # Recorded context but nothing yet conditions on it — the marginal is
        # honest but under-specified (§3), the categorical analog of the binary
        # `unstable`/narrow-breadth caveats.
        if recorded_keys and not by_context:
            caveats.add("under_specified")

        return CategoricalPrediction(post.values, post.unknown,
                                     post.total_observations, snapshot,
                                     frozenset(caveats), by_context)

    def _categorical_observations(
            self, idx: Index, fact_id: str) -> list[tuple[dict[str, str], str]]:
        """The fact's categorical observations as (context, value) pairs, the
        context augmented with the Δ10 derived frames (so a guard admitted on
        `derived:*` breaks down here exactly like a recorded key). Pure read over
        `observations`/`obs_context`/`events`, ORDER BY event_seq, so it
        reproduces under replay/predict_at (I3/I8)."""
        rows = idx.query(
            "SELECT o.event_seq AS event_seq, o.value AS value, e.ts AS ts "
            "FROM observations o JOIN events e ON e.seq = o.event_seq "
            "WHERE o.fact_id=? AND o.value IS NOT NULL ORDER BY o.event_seq",
            (fact_id,))
        ctx_rows = idx.query(
            "SELECT oc.event_seq AS event_seq, oc.key AS key, oc.value AS value "
            "FROM obs_context oc JOIN observations o ON o.event_seq = oc.event_seq "
            "WHERE o.fact_id=?", (fact_id,))
        by_seq: dict[int, dict[str, str]] = {}
        for r in ctx_rows:
            by_seq.setdefault(int(r["event_seq"]), {})[r["key"]] = r["value"]
        base = [by_seq.get(int(r["event_seq"]), {}) for r in rows]
        prevs: list = [None] + [rows[i - 1]["value"] for i in range(1, len(rows))]
        aug = curiosity_stats_mod.augment_derived(
            base, [int(r["ts"]) for r in rows], prevs)
        return [(aug[i], r["value"]) for i, r in enumerate(rows)]

    def _categorical_context_breakdown(
            self, obs: list[tuple[dict[str, str], str]], key: str,
            alpha: float) -> dict[str, dict[str, Any]]:
        """Per-context-value CRP predictive for ONE conditioning key (design §3).

        Reuses Feature A's `outcome_breakdown` (each fact-value projected
        one-vs-rest, so the residual bucket + integer tallies are the SAME helper
        the binary `distribution()` uses) to build per-context per-value counts,
        then runs the §2 CRP predictive INDEPENDENTLY per context group via the
        shared `counts.category_group_posterior` kernel. Deterministic: context
        groups in canonical order (`__residual__` last), values ORDER BY value."""
        values = sorted({v for _, v in obs})
        totals: dict[str, int] = {}
        per_value: dict[str, dict[str, int]] = {}
        for v in values:
            proj = [(ctx, ov == v) for ctx, ov in obs]
            for cv, g in curiosity_stats_mod.outcome_breakdown(proj, key).items():
                totals[cv] = g.n
                per_value.setdefault(cv, {})[v] = g.k
        out: dict[str, dict[str, Any]] = {}
        for cv in sorted(totals,
                         key=lambda c: (c == curiosity_stats_mod.RESIDUAL_BUCKET, c)):
            post = counts_mod.category_group_posterior(
                per_value.get(cv, {}), totals[cv], alpha)
            out[cv] = {"values": post.values, "unknown": post.unknown,
                       "n": totals[cv]}
        return out

    def _build_problem(self, idx: Index, clo: closure_mod.Closure, pred: str,
                       args: list[Any]) -> predict_mod.Problem:
        fid = facts_mod.lookup(idx, pred, args) or fact_key(pred, args)
        atom = (pred, tuple(args))
        supports = [s for s in clo.support.get(atom, []) if s]
        dnf: list[frozenset[str]] = []
        for support in supports:
            conj = frozenset(s for s in support
                             if idx.one("SELECT id FROM facts WHERE id=?", (s,)))
            if conj:
                dnf.append(conj)
        if not dnf:
            dnf = [frozenset({fid})]

        needed = {f for conj in dnf for f in conj}
        cons = [constraints_mod.parse(r) for r in idx.query("SELECT * FROM constraints")]
        groups: list[list[str]] = []
        if cons:
            all_facts = [(r["pred"], json.loads(r["args_json"]), r["id"])
                         for r in idx.query("SELECT id, pred, args_json FROM facts")]
            for key, members in sorted(constraints_mod.groups_for(cons, all_facts).items()):
                if needed & set(members):
                    groups.append(sorted(members))
                    needed |= set(members)

        states: dict[str, predict_mod.FactState] = {}
        caveats: set[str] = set()
        sources: dict[str, int] = {}
        confusion: dict[str, tuple[int, int, int, int]] = {}
        response_lr: dict = {}
        for target in sorted(needed):
            states[target] = self._fact_state(idx, target)
            for actor, vote, grade, _ in states[target].votes:
                if actor not in confusion:
                    confusion[actor] = reliability_mod.confusion(idx, actor)
                if grade > 0 and (actor, vote, grade) not in response_lr:
                    response_lr[(actor, vote, grade)] = \
                        reliability_mod.response_log_lr(idx, actor, bool(vote), grade)
            src = idx.one(
                "SELECT source_ref FROM events WHERE seq=("
                "SELECT admitted_by_event FROM facts WHERE id=?)", (target,))
            if src is not None and src["source_ref"]:
                sources[src["source_ref"]] = sources.get(src["source_ref"], 0) + 1
            if states[target].flagged:
                caveats.add("under_specified")
            if states[target].narrow:
                caveats.add("narrow_breadth")
            # H8b: a crisp fact whose votes alternate is FLAKY — the prediction
            # took the grouped-by-key path, and its instability may not trip the
            # overdispersion sweep (a single-context alternating fact has no
            # covariate and no block-scale spread), so surface it explicitly or
            # flakiness stays silent — the whole point of detecting it. Pure
            # function of the votes, so predict_at reproduces it (I8).
            if states[target].votes and predict_mod.is_flaky(states[target].votes):
                caveats.add("unstable")
            # Δ13: this scalar pools observations from more than one
            # intervention regime — P(·|observe) and P(·|do) are different
            # quantities and the marginal is an average over the boundary. The
            # per-regime numbers live in distribution(). Pure read (I8).
            if self._regime_mixed(idx, target):
                caveats.add("regime_mixed")
        if any(v >= 2 for v in sources.values()) and len(needed) >= 2:
            caveats.add("shared_provenance")
        return predict_mod.Problem(fid, dnf, states, groups, caveats, confusion,
                                   response_lr, self._actor_discounts(idx))

    def _regime_mixed(self, idx: Index, fact_id: str) -> bool:
        """Δ13: does this fact's observation set span more than one intervention
        regime? True when any `do:` context key carries two or more distinct
        values, or is recorded on some observations but not all (absent IS a
        regime: nobody was intervening). Deterministic read over the index."""
        total_row = idx.one(
            "SELECT COUNT(*) AS n FROM observations WHERE fact_id=?", (fact_id,))
        total = int(total_row["n"]) if total_row else 0
        if total == 0:
            return False
        for r in idx.query(
                "SELECT oc.key AS key, COUNT(DISTINCT oc.value) AS nv, "
                "COUNT(*) AS n FROM obs_context oc "
                "JOIN observations o ON o.event_seq = oc.event_seq "
                "WHERE o.fact_id=? AND oc.key LIKE 'do:%' GROUP BY oc.key",
                (fact_id,)):
            if int(r["nv"]) >= 2 or int(r["n"]) < total:
                return True
        return False

    def _fact_state(self, idx: Index, fact_id: str) -> predict_mod.FactState:
        row = idx.one("SELECT stmt_type, dispersion_flag, breadth_class FROM facts "
                      "WHERE id=?", (fact_id,))
        stmt_type = row["stmt_type"] if row else "crisp"
        # A categorical fact is a LEAF QUERY handled upstream in _predict_with by
        # _predict_categorical (design §3, decision 3); it is never a proof
        # literal in v1, so it never reaches _fact_state (whose scalar epi/alea
        # composition would be meaningless for it — its counts live in
        # fact_category_counts, not fact_counts).
        composed = counts_mod.compose(idx, [fact_id])
        epi, alea = counts_mod.posterior_params(composed, stmt_type)
        if row is None:
            # Never admitted: no gate evidence, so no admission pseudocount either.
            epi = (1.0 + composed.epi_a, 1.0 + composed.epi_b)
        votes: tuple = ()
        if stmt_type == "crisp":
            # v0.3 Δ1: attributed votes supersede the epi Beta for crisp facts —
            # same events at finer grain. Ordered deterministically so the
            # composition is independent of insertion order.
            vrows = idx.query(
                "SELECT actor, outcome, grade, context_sig FROM observations "
                "WHERE fact_id=? AND channel='epi' "
                "ORDER BY actor, context_sig, event_seq", (fact_id,))
            votes = tuple((r["actor"], int(r["outcome"]), int(r["grade"]),
                           r["context_sig"]) for r in vrows)
        return predict_mod.FactState(
            fact_id=fact_id, stmt_type=stmt_type, epi=epi, alea=alea,
            pinned_negative=facts_mod.is_negatively_pinned(idx, fact_id),
            flagged=bool(row["dispersion_flag"]) if row else False,
            narrow=(row["breadth_class"] == "narrow") if row else False,
            votes=votes)

    # ── introspection ────────────────────────────────────────────────────────
    def raw_counts(self, fact_id: str) -> dict[tuple[str, str], tuple[int, int]]:
        return counts_mod.raw_counts(self.index, self._alias_ids(fact_id))

    def composed_counts(self, fact_id: str) -> counts_mod.Composed:
        return counts_mod.compose(self.index, self._alias_ids(fact_id))

    def _alias_ids(self, fact_id: str) -> list[str]:
        """Union-at-read over the alias closure. Counts are never merged (I11)."""
        row = self.index.one("SELECT pred, args_json FROM facts WHERE id=?", (fact_id,))
        if row is None:
            return [fact_id]
        args = json.loads(row["args_json"])
        return facts_mod.resolve_ids(self.index, row["pred"], args)

    def fact_id_for(self, stmt: Mapping[str, Any]) -> Optional[str]:
        return facts_mod.lookup(self.index, stmt["pred"], list(stmt["args"]))

    def _actor_discounts(self, idx: Optional[Index] = None) -> dict[str, float]:
        """Operator-set trust discounts for the crisp vote path.

        Only *explicit* overrides count — read from the `reliability_overrides`
        table, which is folded from `reliability` ledger events (never from
        settlements). Learned reliability lives in the confusion ledger and
        already speaks through the two-coin LR; folding E[rel] in as well would
        double-count the same settlements. An untouched store returns {} and
        composes byte-identically to before this existed.

        Reads from `idx` so a snapshot replay (predict_at) tempers with the
        overrides as of its own ledger position, not the live store's.
        """
        target = idx if idx is not None else self.index
        out: dict[str, float] = {}
        for row in target.query(
                "SELECT actor, frame, rel_a, rel_b FROM reliability_overrides"):
            a, b = float(row["rel_a"]), float(row["rel_b"])
            if row["frame"] == reliability_mod.FACT_FRAME and (a + b) > 0:
                out[row["actor"]] = a / (a + b)
        return out

    def set_reliability(self, actor: str, frame: str, a: float, b: float,
                        authority: str = "human:operator") -> None:
        """Operator override on a source's trust. Moves BOTH channels.

        On frequency facts it discounts the aleatoric trial contribution; on
        crisp facts it tempers the source's vote evidence (v0.3 Δ1 replaced the
        epi Beta with two-coin votes, and before this the lever silently missed
        them — see bench/CLAIMS_HARDENING.md F2).

        A first-class ledger event, not a side file: it folds in sequence order
        like everything else, so a ledger-only rebuild reproduces it (I1) and it
        composes with settlements at its true position (I3).
        """
        self._authorize(authority, "set_reliability")
        # Validate before appending (C3): actor_reliability's frame CHECK would
        # otherwise reject the event only after it is already in the chain,
        # bricking every future replay.
        if frame not in ("internal", "external"):
            raise ValueError(
                f"reliability frame must be 'internal' or 'external', got {frame!r}")
        payload = {"actor": actor, "frame": frame,
                   "rel_a": float(a), "rel_b": float(b)}
        ev = self.ledger.append("reliability", authority, payload)
        apply_mod.apply_event(self.index, ev, payload)
        self.index.commit()

    def why(self, obj_id: str) -> dict[str, Any]:
        row = self.index.one("SELECT * FROM facts WHERE id=?", (obj_id,))
        if row is None:
            return {"id": obj_id, "found": False}
        args = json.loads(row["args_json"])
        raw = self.raw_counts(obj_id)
        composed = self.composed_counts(obj_id)
        keys = self._context_keys(obj_id)
        derivation = self.derive({"pred": row["pred"], "args": args}, budget=10_000)
        return {
            "id": obj_id, "found": True, "pred": row["pred"], "args": args,
            "stmt_type": row["stmt_type"], "kind": row["kind"],
            "structural": row["structural"], "numeric": row["numeric"],
            "dispersion_flag": bool(row["dispersion_flag"]),
            "breadth_class": row["breadth_class"],
            "valid_from": row["valid_from"], "valid_to": row["valid_to"],
            "gate_run": self._gate_run_for(obj_id),
            "span_provenance": self._spans_for(obj_id),
            "raw_counts": {f"{a}|{c}": [n, k] for (a, c), (n, k) in raw.items()},
            "composed_counts": {"epi_a": composed.epi_a, "epi_b": composed.epi_b,
                                "alea_n": composed.alea_n, "alea_k": composed.alea_k},
            "source_diversity": keys,
            "derivation": {"status": derivation.status, "quality": derivation.quality,
                           "proof": derivation.proof},
        }

    def distribution(self, stmt: Mapping[str, Any]) -> dict[str, Any]:
        """Read-time outcome breakdown for a flaky BINARY (crisp/frequency) fact.

        A PURE projection over data the store already keeps — the fact's
        observations, their recorded `obs_context`, the curiosity sweep's stored
        verdict, and any admitted conditioning guard. It writes nothing, moves no
        count, changes no closure_hash, and never runs predict(): the scalar
        prediction is byte-identical whether or not this is ever called. It is the
        honest companion to the `unstable` caveat — instead of only saying a fact
        is flaky, it says *how* it splits by context and how much of the spread no
        recorded variable accounts for.

        Shape::

            {
              "found": bool,              # False (fact_id None) if the stmt names no fact
              "fact_id": str | None,
              "stmt_type": "crisp" | "frequency",
              "n_obs": int,               # observations attributed to the fact
              "flaky": bool,              # dispersed, or (crisp) vote-alternating
              "dispersion_flag": bool,    # the stored sweep verdict
              "modes": {                  # PART 1 — per recorded context key
                <key>: {
                  <value>: {"p": <true-rate>, "n": <count>},
                  ...,
                  "__residual__": {"p": .., "n": ..}  # obs that did NOT record <key>
                }, ...
              },
              "derived_modes": {          # Δ10 — same shape, per SYNTHESIZED frame
                "derived:hour": {...}, "derived:prev": {...}, ...
              },
              "residual": {               # PART 2 — the unexplained "unknown" share
                "conditioning_key": <key> | None,  # the admitted guard's variable, if any
                "explained": float,       # η² of the guard partition; 0 with no guard
                "unexplained": float,     # 1 - explained when dispersed, else 0
                "dispersion_stat": float | None,   # stored Tarone overdispersion Z
              },
            }

        `modes` is built by the reusable `curiosity.outcome_breakdown` helper
        (a future categorical fact type breaks its value distribution down with
        the same helper). `explained` is the correlation ratio η² of an *admitted*
        guard's partition — the share of the binary outcome's variance the guard
        variable accounts for; with no admitted guard it is 0 and the whole
        dispersion is unexplained. `dispersion_stat` is surfaced raw for reference,
        not recomputed. A non-dispersed fact returns trivial modes and a zero
        residual.
        """
        fid = facts_mod.lookup(self.index, stmt["pred"], list(stmt["args"]))
        if fid is None:
            return {"found": False, "fact_id": None, "stmt_type": None,
                    "n_obs": 0, "flaky": False, "dispersion_flag": False,
                    "modes": {}, "derived_modes": {},
                    "residual": {"conditioning_key": None,
                                 "explained": 0.0, "unexplained": 0.0,
                                 "dispersion_stat": None}}
        row = self.index.one(
            "SELECT stmt_type, dispersion_flag FROM facts WHERE id=?", (fid,))
        stmt_type = row["stmt_type"]
        dispersion_flag = bool(row["dispersion_flag"])
        ids = self._alias_ids(fid)

        # All observations attributed to the fact (alias-unioned), in a stable
        # order so the crisp vote sequence matches what _fact_state feeds predict.
        placeholders = ",".join("?" * len(ids))
        rows = self.index.query(
            f"SELECT event_seq, outcome, actor, grade, context_sig FROM observations "
            f"WHERE fact_id IN ({placeholders}) "
            f"ORDER BY actor, context_sig, event_seq", ids)
        ctx_rows = self.index.query(
            f"SELECT oc.event_seq AS event_seq, oc.key AS key, oc.value AS value "
            f"FROM obs_context oc JOIN observations o ON o.event_seq = oc.event_seq "
            f"WHERE o.fact_id IN ({placeholders})", ids)
        by_seq: dict[int, dict[str, str]] = {}
        for r in ctx_rows:
            by_seq.setdefault(int(r["event_seq"]), {})[r["key"]] = r["value"]
        obs = [(by_seq.get(int(r["event_seq"]), {}), bool(r["outcome"]))
               for r in rows]

        # PART 1 — per-context-key breakdown, via the reusable helper. `modes`
        # covers RECORDED context only, keeping the docstring's promise; the
        # synthesized frames get their own section below.
        keys = sorted({k for ctx, _ in obs for k in ctx})
        modes: dict[str, Any] = {}
        for key in keys:
            groups = curiosity_stats_mod.outcome_breakdown(obs, key)
            modes[key] = {v: {"p": g.k / g.n, "n": g.n}
                          for v, g in sorted(groups.items())}

        # Δ10 — derived frames, chronological (prev/hour need event order, not
        # vote order): the same pure augmentation the sweep searches over, so a
        # guard the sweep admitted on `derived:*` is inspectable here too.
        crows = self.index.query(
            f"SELECT o.event_seq, o.outcome, e.ts FROM observations o "
            f"JOIN events e ON e.seq = o.event_seq "
            f"WHERE o.fact_id IN ({placeholders}) ORDER BY o.event_seq", ids)
        cbase = [by_seq.get(int(r["event_seq"]), {}) for r in crows]
        prevs: list = [None] + ["T" if bool(crows[i - 1]["outcome"]) else "F"
                                for i in range(1, len(crows))]
        caug = curiosity_stats_mod.augment_derived(
            cbase, [int(r["ts"]) for r in crows], prevs)
        derived_obs = [(caug[i], bool(r["outcome"])) for i, r in enumerate(crows)]
        derived_keys = sorted({k for ctx, _ in derived_obs for k in ctx
                               if curiosity_stats_mod.is_derived(k)})
        derived_modes: dict[str, Any] = {}
        for key in derived_keys:
            groups = curiosity_stats_mod.outcome_breakdown(derived_obs, key)
            derived_modes[key] = {v: {"p": g.k / g.n, "n": g.n}
                                  for v, g in sorted(groups.items())}

        # A crisp fact whose votes alternate is flaky even when the sweep's
        # overdispersion test stays silent (H8b) — the same signal predict()
        # surfaces as `unstable`. Pure function of the votes, so it replays.
        flaky_votes = False
        if stmt_type == "crisp":
            votes = tuple((r["actor"], int(r["outcome"]), int(r["grade"]),
                           r["context_sig"]) for r in rows)
            flaky_votes = bool(votes) and predict_mod.is_flaky(votes)
        dispersed = dispersion_flag or flaky_votes

        # PART 2 — the unexplained "unknown" residual. An admitted guard names the
        # conditioning variable; η² over its partition is the explained share.
        cond_key = None
        for r in self.index.query(
                "SELECT body_json FROM candidates WHERE kind='guard' "
                "AND status='admitted' ORDER BY event_seq"):
            body = json.loads(r["body_json"])
            if body.get("target_fact") in ids:
                cond_key = body.get("conditioning_key")   # most recent match wins
        explained = 0.0
        if cond_key is not None:
            # A derived conditioning key (Δ10) lives on the augmented projection;
            # a recorded one on the raw observations. Either way η² is the same
            # deterministic decomposition.
            src = obs if cond_key in keys else (
                derived_obs if cond_key in derived_keys else None)
            if src is not None:
                value_groups = [g for _, g in sorted(
                    curiosity_stats_mod.partition_by_key(src, cond_key).items())]
                explained = curiosity_stats_mod.explained_fraction(value_groups)
        unexplained = (1.0 - explained) if dispersed else 0.0
        oq = self.index.one(
            "SELECT dispersion_stat FROM open_questions "
            "WHERE kind='dispersion' AND target_id=?", (fid,))
        dispersion_stat = oq["dispersion_stat"] if oq is not None else None

        return {
            "found": True, "fact_id": fid, "stmt_type": stmt_type,
            "n_obs": len(rows), "flaky": dispersed,
            "dispersion_flag": dispersion_flag, "modes": modes,
            "derived_modes": derived_modes,
            "residual": {"conditioning_key": cond_key, "explained": explained,
                         "unexplained": unexplained,
                         "dispersion_stat": dispersion_stat},
        }

    def _gate_run_for(self, fact_id: str) -> Optional[str]:
        row = self.index.one(
            "SELECT gate_run_id FROM candidates WHERE status='admitted' AND kind='fact' "
            "AND body_json LIKE ? ORDER BY event_seq DESC LIMIT 1",
            (f"%{fact_id}%",))
        if row is not None:
            return row["gate_run_id"]
        row = self.index.one(
            "SELECT payload_hash FROM events WHERE seq=(SELECT admitted_by_event "
            "FROM facts WHERE id=?)", (fact_id,))
        if row is None:
            return None
        payload = self.ledger.payload(row["payload_hash"]) or {}
        return payload.get("gate_run_id")

    def _spans_for(self, fact_id: str) -> list[str]:
        rows = self.index.query(
            "SELECT DISTINCT span_ref FROM candidates WHERE span_ref IS NOT NULL "
            "AND kind='fact' AND body_json LIKE ?", (f"%{fact_id}%",))
        return [r["span_ref"] for r in rows]

    def _context_keys(self, fact_id: str) -> dict[str, int]:
        rows = self.index.query(
            "SELECT oc.key AS key, COUNT(DISTINCT oc.value) AS distinct_values "
            "FROM obs_context oc JOIN observations o ON o.event_seq = oc.event_seq "
            "WHERE o.fact_id=? GROUP BY oc.key ORDER BY oc.key", (fact_id,))
        return {r["key"]: int(r["distinct_values"]) for r in rows}

    def questions(self, scope: str = "*") -> list[dict[str, Any]]:
        sql = "SELECT * FROM open_questions WHERE status='open'"
        params: tuple = ()
        if scope not in ("*", "", None):
            sql += " AND kind=?"
            params = (scope,)
        return [{
            "id": r["id"], "kind": r["kind"], "target_kind": r["target_kind"],
            "target_id": r["target_id"],
            "residual_partition": json.loads(r["residual_partition"] or "{}"),
            "dispersion_stat": r["dispersion_stat"],
            "ruled_out": json.loads(r["ruled_out_json"] or "[]"),
            "suggested_measurement": r["suggested_measurement"],
            "status": r["status"],
        } for r in self.index.query(sql + " ORDER BY id", params)]

    def events_since(self, cursor: int,
                     kinds: Optional[set[str]] = None) -> list[dict[str, Any]]:
        rows = self.index.query(
            "SELECT seq, ts, kind, actor, payload_hash, source_ref, context_sig, hash "
            "FROM events WHERE seq > ? ORDER BY seq", (int(cursor),))
        out = []
        for r in rows:
            if kinds and r["kind"] not in kinds:
                continue
            out.append({"id": int(r["seq"]), "seq": int(r["seq"]), "ts": int(r["ts"]),
                        "kind": r["kind"], "actor": r["actor"],
                        "payload_hash": r["payload_hash"],
                        "source_ref": r["source_ref"],
                        "context_sig": r["context_sig"], "hash": r["hash"]})
        return out

    def health(self) -> dict[str, Any]:
        settled = self.index.query(
            "SELECT frame, settlement, COUNT(*) AS c FROM claims "
            "WHERE resolved_ts IS NOT NULL GROUP BY frame, settlement")
        total = sum(int(r["c"]) for r in settled) or 0
        external = sum(int(r["c"]) for r in settled if r["frame"] == "external")
        breadth = {r["breadth_class"] or "unclassified": int(r["c"])
                   for r in self.index.query(
                       "SELECT breadth_class, COUNT(*) AS c FROM facts "
                       "GROUP BY breadth_class")}
        quota_rows = self.index.query(
            "SELECT actor, kind, SUM(used) AS used FROM quota_usage "
            "GROUP BY actor, kind ORDER BY actor, kind")
        diagnostics = [{"kind": r["kind"], **json.loads(r["detail_json"])}
                       for r in self.index.query(
                           "SELECT kind, detail_json FROM diagnostics "
                           "ORDER BY seq DESC LIMIT 100")]
        return {
            "calibration": calibration_mod.report(self.index),
            "external_settled_ratio": (external / total) if total else None,
            "invariants": [dict(r) for r in self.index.query("SELECT * FROM invariants")],
            "breadth_distribution": breadth,
            "queue_depth": int(self.index.one(
                "SELECT COUNT(*) AS c FROM candidates WHERE status='pending'")["c"]),
            "quota_usage": [{"actor": r["actor"], "kind": r["kind"],
                             "used": int(r["used"])} for r in quota_rows],
            "constraint_rejection_rate": self._last_rejection_rate,
            "events": list(self._health_events) + diagnostics,
            "ledger_head": self.ledger.head(),
            "retrieval_log_size": self.retrieval_log.count(),
        }

    _last_rejection_rate: float = 0.0
    # Fold instrumentation (checkpoint fast path): how many tail events the last
    # _refold folded, and the checkpoint seq it restored from (0 = full replay).
    _last_tail_folded: int = 0
    _last_checkpoint_seq: int = 0
    # H6b sweep instrumentation: the fact ids the last _refold RE-SWEPT on the
    # incremental fast path (the tail-touched ones); None marks a full sweep.
    _last_resweep_ids: Optional[list[str]] = None

    # ── test-only fault injection (§6.1) ─────────────────────────────────────
    def corrupt(self, what: str, arg: str = "") -> None:
        if what == "torn_tail":
            self.ledger.append_raw_line('{"seq": 999999, "ts": 0, "kind": "obser')
        elif what == "drop_index":
            self.index.drop()
        elif what == "delete_payload":
            self.ledger.delete_payload(arg)
        else:
            raise ValueError(f"unknown fault {what!r}")
